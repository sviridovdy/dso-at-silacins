#!/bin/bash
LOG_FILE="./logs/access.log"

jq -c 'select(.host != .ssl_server_name)' "$LOG_FILE"
